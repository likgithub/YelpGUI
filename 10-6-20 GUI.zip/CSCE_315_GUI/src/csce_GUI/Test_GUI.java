package csce_GUI;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import java.awt.GridBagLayout;
import java.awt.PopupMenu;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Hashtable;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import java.awt.Label;
import java.awt.Font;
import java.awt.event.TextListener;
import java.awt.event.TextEvent;
import java.awt.ScrollPane;
import java.sql.*;
import javax.swing.JOptionPane;

public class Test_GUI {

	private JFrame frame;
	String select = "SELECT";
	String where = "WHERE";
	String output_option = "";
	String categoryInput = "";
	String out_limit = "5";
	String starsSelected = "";
	String reviewCountSelected = "";
	String stateSelected = "";
	String citySelected = "";
	String postalCodeSelected = "";
	private Connection conn = null;
	private dbSetup my = new dbSetup();
	boolean nameView = false;
	boolean addressView = false;
	boolean cityView = false;
	boolean stateView = false;
	boolean postalView = false;
	boolean starView = false;
	boolean reviewCountView = false;
	
	public void callAll(){
		establishConnection();
		//testQuery();
		//closeConnection();
	}
	public void callAll2(){
		
     
    
	}
	public void establishConnection() {
		
		   
	    try {
        Class.forName("org.postgresql.Driver");
        conn = DriverManager.getConnection("jdbc:postgresql://csce-315-db.engr.tamu.edu/db905_group1_project2",
           my.user, my.pswd);
     } catch (Exception e) {
        e.printStackTrace();
        System.err.println(e.getClass().getName()+": "+e.getMessage());
        System.exit(0);
     }//end try catch
     JOptionPane.showMessageDialog(null,"Opened database successfully");
	    
		  
	}
	private void closeConnection() {
		//closing the connection
    try {
      conn.close();
      JOptionPane.showMessageDialog(null,"Connection Closed.");
    } catch(Exception e) {
      JOptionPane.showMessageDialog(null,"Connection NOT Closed.");
    }//end try catch
	}

	
	/**
	 * Launch the application.
	 */
	//sets frame to visible. Needs to be called in main
	public void set_visible() {
		frame.setVisible(true);
	}

	//execute system queries
	void serverRequest(String command){
		String name = "";
		try{
			//create a statement object
			Statement stmt = conn.createStatement();
			//create an SQL statement
			String sqlStatement = command;
			//send statement to DBMS
			ResultSet result = stmt.executeQuery(sqlStatement);

			//OUTPUT
			//JOptionPane.showMessageDialog(null,"10 entries in business category");
			//System.out.println("______________________________________");
			while (result.next()) {
				//System.out.println(result.getString("cus_lname"));
				name += result.getString("name")+"\n";
			}
			//add file input
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		JOptionPane.showMessageDialog(null,name);
	}
	//displays name and address
	void serverRequest2(String command){
		String name = "";
		try{
			//create a statement object
			Statement stmt = conn.createStatement();
			//create an SQL statement
			String sqlStatement = command;
			//send statement to DBMS
			ResultSet result = stmt.executeQuery(sqlStatement);

			//OUTPUT
			//System.out.println("______________________________________");
			while (result.next()) {
				//System.out.println(result.getString("cus_lname"));
				name += result.getString("name")+" | "+result.getString("address")+"\n";
			}
			//add file input
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		JOptionPane.showMessageDialog(null,name);
	}

	String buildOutput(ResultSet result){
		String name = "";
		try{
			while (result.next()) {
					//System.out.println(result.getString("cus_lname"));
					name += result.getString("name")+" | "+result.getString("address")+"\n";
				}
		
			//add file input
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		return name;
	}


	//split checkboxes by tables
	void execute() {
		String command = "";
		if(nameView && (categoryInput != "")) {
			command = "SELECT name from business_category WHERE category LIKE '%"+categoryInput+"%' LIMIT "+out_limit+";";
			serverRequest(command);
			categoryInput = "";
		}
		else if(nameView && starsSelected != "" && reviewCountSelected == "2000+"){
			command = "SELECT name, rating, review_count FROM business_review WHERE CAST(rating AS REAL) = "+starsSelected+" ORDER BY CAST(review_count AS INTEGER) DESC LIMIT "+out_limit+";";
			serverRequest(command);
		}
		else if(nameView && addressView && stateSelected != "" && starsSelected =="5" ){
			command = "SELECT name, address FROM business_review INNER JOIN business_location ON business_review.business_id = business_location.business_id WHERE business_location.state LIKE '%"+stateSelected+"%' ORDER BY rating DESC LIMIT "+out_limit;
			serverRequest2(command);
		}
		// get name and address criteria: zipcode
		// else if(nameView && addressView){
		// 	command = "SELECT name, address FROM business_category, business_location WHERE business_location.postal_code LIKE '%77840%' LIMIT 10";
		// 	serverRequest(command);
		// }
		// 
		else if(nameView && addressView && postalCodeSelected != ""){
			command = "SELECT name, address FROM business_review JOIN business_location ON business_review.business_id = business_location.business_id WHERE postal_code LIKE '%"+postalCodeSelected+"%' LIMIT "+out_limit+";";
			serverRequest2(command);
		}
		else if(nameView && addressView && citySelected != ""){
			command = command = "SELECT name, address FROM business_review JOIN business_location ON business_review.business_id = business_location.business_id WHERE postal_code LIKE '%"+citySelected+"%' LIMIT "+out_limit+";";;
			serverRequest2(command);
		}

		System.out.println(command);
		// output_option = "";
		// categoryInput = "";
		// out_limit = "5";
		// starsSelected = "";
		// reviewCountSelected = "";
		// stateSelected = "";
		// citySelected = "";
	}
	/**
	 * Create the application.
	 */
	public Test_GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 989, 487);
		frame.setDefaultCloseOperation(frame.DO_NOTHING_ON_CLOSE);
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		{
			JLabel lblNewLabel_1 = new JLabel("Search Criteria:");
			lblNewLabel_1.setBounds(58, 183, 99, 16);
			frame.getContentPane().add(lblNewLabel_1);
		}
		JLabel lblNewLabel = new JLabel("View:");
		lblNewLabel.setBounds(96, 127, 61, 24);
		frame.getContentPane().add(lblNewLabel);
		
		
		String starQuery = "NONE";
		
		
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Connection
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		Button button = new Button("Close Connection and Exit");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("global variable select "+ select);
				closeConnection();
				System.exit(0);
				
			}
		});
		button.setBounds(745, 31, 168, 24);
		frame.getContentPane().add(button);
		
		Button button2 = new Button("Test Query");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("global variable select "+ select);
				execute();
				
				
			}
		});
		button2.setBounds(811, 79, 79, 24);
		frame.getContentPane().add(button2);

		
		
		

		
		
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Begin criteria selectors
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		Choice choice_reviewCount = new Choice();
		choice_reviewCount.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String review_selection = choice_reviewCount.getSelectedItem();
				switch(review_selection) {
					case "0 - 500":
						reviewCountSelected = "0 - 500";
						//String starQuery = "1";
						break;
					case "500 - 1000":
						reviewCountSelected = "500 - 1000";
						break;
					case "1000 - 1500":
						reviewCountSelected = "1000 - 1500";
						break;
					case "1500 - 2000":
						
						reviewCountSelected = "1500 - 2000";
						break;
					case "2000+":

						reviewCountSelected = "2000+";
						break;
					default:
						System.out.println("NO SELECTION");
				}
			}
		});
		//PopupMenu popupmenu = new 
		String range1 = new String("0 - 500");
		String range2 = new String("500 - 1000");
		String range3 = new String("1000 - 1500");
		String range4 = new String("1500 - 2000");
		String range5 = new String("2000+");
		choice_reviewCount.add(range1);
		choice_reviewCount.add(range2);
		choice_reviewCount.add(range3);
		choice_reviewCount.add(range4);
		choice_reviewCount.add(range5);
		
		choice_reviewCount.setBounds(316, 217, 75, 22);
		frame.getContentPane().add(choice_reviewCount);
		
/////////////////////////////////////////////////////////////////
		Choice choiceStar = new Choice();
		choiceStar.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String star_selection = choiceStar.getSelectedItem();
				switch(star_selection) {
					case "1 Star":
						//System.out.println("stars > 1");
						String starQuery = "1";
						break;
					case "2 Stars":
						//System.out.println("stars > 2");
						break;
					case "3 Stars":
						//System.out.println("stars > 3");
						select = "three stars";
						break;
					case "4 Stars":
						//System.out.println("stars > 4");
						break;
					case "5 Stars":
						//System.out.println("stars > 5");
						starsSelected = "5";
						break;
					default:
						System.out.println("NO SELECTION");
				}
			}
		});
		//PopupMenu popupmenu = new 
		String star1 = new String("1 Star");
		String star2 = new String("2 Stars");
		String star3 = new String("3 Stars");
		String star4 = new String("4 Stars");
		String star5 = new String("5 Stars");
		choiceStar.add(star1);
		choiceStar.add(star2);
		choiceStar.add(star3);
		choiceStar.add(star4);
		choiceStar.add(star5);
		
		choiceStar.setBounds(179, 217, 61, 22);
		frame.getContentPane().add(choiceStar);

		/////////////////////////////////////////////////////////////////

		SortedMap<String, String> states = new TreeMap<String, String>();
		states.put("WY", "test");
		states.put("WI", "test2");
		states.put("WV", "test3");
		states.put("WA", "WA");
		states.put("VA", "test2");
		states.put("VT", "test3");
		states.put("UT", "test");
		states.put("TX", "test2");
		states.put("TN", "test3");
		states.put("SD", "test");
		states.put("SC", "test2");
		states.put("RI", "test3");
		states.put("PA", "test");
		states.put("OR", "test2");
		states.put("OK", "test3");
		states.put("OH", "test");
		states.put("ND", "test2");
		states.put("NY", "test3");
		states.put("NM", "test");
		states.put("NJ", "test2");
		states.put("NH", "test3");
		states.put("NV", "test");
		states.put("NE", "test2");
		states.put("MT", "test3");
		states.put("MO", "test");
		states.put("MS", "test2");
		states.put("MN", "test3");
		states.put("MI", "test");
		states.put("MA", "test2");
		states.put("MD", "test3");
		states.put("ME", "test");
		states.put("LA", "test2");
		states.put("KY", "test3");
		states.put("KS", "test");
		states.put("IA", "test2");
		states.put("IN", "test3");
		states.put("IL", "test");
		states.put("ID", "test2");
		states.put("HI", "test3");
		states.put("GA", "test");
		states.put("FL", "test2");
		states.put("DE", "test3");
		states.put("CT", "test");
		states.put("CO", "test2");
		states.put("CA", "test3");
		states.put("AR", "test");
		states.put("AZ", "AZ");
		states.put("AK", "AK");
		states.put("AL", "AL");

		Choice choiceState = new Choice();
		choiceState.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String state_selection = choiceState.getSelectedItem();
				try {
					//System.out.println(states.get(state_selection));
					stateSelected = states.get(state_selection);
				}catch(Exception ex){
					System.out.println("no selection");
				}
			}
		});
		// PopupMenu popupmenu = new 

		Set<String> keys = states.keySet();

		for(String key : keys){
			choiceState.add(key);
		}

		choiceState.setBounds(589, 217, 61, 22);
		frame.getContentPane().add(choiceState);
	
		////////////////////////////////////////////////////////////
		
		{
			String star7 = new String("example");
		}
		
		
		
		
		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//END criteria selectors
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
//output
		Choice choice_output = new Choice();
		choice_output.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String limit_choice = choice_output.getSelectedItem();
				switch(limit_choice) {
					case "5 lines":
						System.out.println("ouput option 5");
						out_limit = "5";
						break;
					case "10 lines":
						System.out.println("ouput option 10");
						out_limit = "10";
						break;
					case "results.txt":
						System.out.println("ouput file");
						//output_option = "5";
						break;
					
					default:
						System.out.println("ouput option 5");
						out_limit = "5";;
				}
			}
		});
		choice_output.setBounds(137, 349, 71, 22);
		frame.getContentPane().add(choice_output);
		String out_lines5 = new String("5 lines");
		String out_lines10 = new String("10 lines");
		String out_file = new String("results.txt");
		choice_output.add(out_lines5);
		choice_output.add(out_lines10);
		choice_output.add(out_file);
		
/////////////////////////////////////////////////////////////////////
//Begin checkboxes
/////////////////////////////////////////////////////////////////////
//		String select = "SELECT";
		
		Checkbox checkbox2 = new Checkbox("review count");
			checkbox2.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					reviewCountView = !reviewCountView;
					//System.out.println("changed");
				}
			});
			checkbox2.setBounds(618, 127, 97, 24);
			frame.getContentPane().add(checkbox2);
		
		{
			Checkbox checkbox = new Checkbox("stars");
			checkbox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					starView = !starView;
					//System.out.println("changed");
				}
			});
			checkbox.setBounds(556, 127, 56, 24);
			frame.getContentPane().add(checkbox);
		}
		{
			Checkbox checkbox = new Checkbox("state");
			checkbox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					stateView = !stateView;
					//System.out.println("changed");
				}
			});
			checkbox.setBounds(397, 127, 56, 24);
			frame.getContentPane().add(checkbox);
		}
		{
			Checkbox checkbox = new Checkbox("city");
			checkbox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					cityView = !cityView;
				}
			});
			checkbox.setBounds(345, 127, 46, 24);
			frame.getContentPane().add(checkbox);
		}
		{
			Checkbox checkbox = new Checkbox("address");
			checkbox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					addressView = !addressView;
					//System.out.println("changed");
				}
			});
			checkbox.setBounds(266, 127, 73, 24);
			frame.getContentPane().add(checkbox);
		}
		{
			Checkbox checkbox = new Checkbox("postal code");
			checkbox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					postalView = !postalView;
					//System.out.println("changed");
				}
			});
			checkbox.setBounds(459, 127, 91, 24);
			frame.getContentPane().add(checkbox);
		}
		
			Checkbox checkbox_business = new Checkbox("business");
			checkbox_business.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					System.out.println("Select before"+select);
					nameView = !nameView;
//					boolean bflag = checkbox_business.getState();
//					if(bflag) {
//						if(true) {
//							String select2 = new String(select);
//							select = "";
//							System.out.println("Select after "+select);
//						}
//					}
					
				}
			});
			checkbox_business.setBounds(179, 127, 81, 24);
			frame.getContentPane().add(checkbox_business);
			
			///text field
			TextField textField_city = new TextField();
			textField_city.addTextListener(new TextListener() {
				public void textValueChanged(TextEvent e) {
					citySelected = textField_city.getText();
					//System.out.println(textField_city.getText());
					
				}
			});
			textField_city.setBounds(446, 217, 71, 24);
			frame.getContentPane().add(textField_city);
			///
		
		{
			JLabel lblNewLabel_1 = new JLabel("Search Criteria:");
			lblNewLabel_1.setBounds(58, 183, 99, 16);
			frame.getContentPane().add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Stars");
			lblNewLabel_2.setBounds(184, 183, 56, 16);
			frame.getContentPane().add(lblNewLabel_2);
		}
		{
			JLabel lblNewLabel_3 = new JLabel("Review_Count");
			lblNewLabel_3.setBounds(302, 183, 97, 16);
			frame.getContentPane().add(lblNewLabel_3);
		}

		{
			JLabel lblNewLabel_4 = new JLabel("State");
			lblNewLabel_4.setBounds(563, 183, 97, 16);
			frame.getContentPane().add(lblNewLabel_4);
		}
		
		
		
		
		
		Label label = new Label("City");
		label.setBounds(447, 183, 70, 24);
		frame.getContentPane().add(label);
		
		Label label_1 = new Label("Yelp Queries");
		label_1.setFont(new Font("Arial Black", Font.BOLD, 14));
		label_1.setBounds(369, 31, 99, 24);
		frame.getContentPane().add(label_1);
		/////////////replace
		{
			//postal code
			TextField textField_postal_code = new TextField();
			textField_postal_code.addTextListener(new TextListener() {
				public void textValueChanged(TextEvent e) {
					postalCodeSelected = textField_postal_code.getText();
					//System.out.println(textField_postal_code.getText());
					
				}
			});
			textField_postal_code.setBounds(676, 215, 73, 24);
			frame.getContentPane().add(textField_postal_code);
		}
		{
			//catergory

			TextField textField_category = new TextField();
			textField_category.addTextListener(new TextListener() {
				public void textValueChanged(TextEvent e) {
					categoryInput = textField_category.getText();
					//System.out.println(textField_category.getText());
					
				}
			});
			textField_category.setBounds(179, 291, 81, 24);
			frame.getContentPane().add(textField_category);

		}
		////////////////////
		{
			Label label_2 = new Label("Postal Code");
			label_2.setBounds(679, 175, 81, 24);
			frame.getContentPane().add(label_2);
		}
		{
			Label label_2 = new Label("Category");
			label_2.setBounds(179, 256, 70, 24);
			frame.getContentPane().add(label_2);
		}
		{
			Label label_2 = new Label("Output:");
			label_2.setBounds(75, 339, 56, 24);
			frame.getContentPane().add(label_2);
		}
		
			
		
//		JTextArea teamPane = new JTextArea(15,40);
//		JScrollPane teamBar = new JScrollPane(teamPane,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
//		teamBar.setBounds(137, 321, 273, 100);
//		frame.getContentPane().add(teamBar);
		
//		ScrollPane scrollPane = new ScrollPane();
//		scrollPane.setBounds(137, 321, 273, 100);
//		frame.getContentPane().add(scrollPane);
		
		
		
//		{
//			PopupMenu popup = new PopupMenu("test");
//			
//		}
		
		
		
	}
}
