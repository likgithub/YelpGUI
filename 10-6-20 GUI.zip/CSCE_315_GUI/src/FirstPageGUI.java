import java.awt.EventQueue;
import java.awt.Label;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

import csce_GUI.dbSetup;

import java.awt.Button;
import java.awt.Choice;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;

public class FirstPageGUI {

	private JFrame frame;
	private Connection conn = null;
	private dbSetup my = new dbSetup();
	private boolean fileFlag = false;
	private BusinessPanel tabBusiness = new BusinessPanel();
	
	
	public void establishConnection() {
		
		   
	    try {
        Class.forName("org.postgresql.Driver");
        conn = DriverManager.getConnection("jdbc:postgresql://csce-315-db.engr.tamu.edu/db905_group1_project2",
           my.user, my.pswd);
     } catch (Exception e) {
        e.printStackTrace();
        System.err.println(e.getClass().getName()+": "+e.getMessage());
        System.exit(0);
     }//end try catch
     JOptionPane.showMessageDialog(null,"Opened database successfully");
	    
		  
	}
	private void closeConnection() {
		//closing the connection
    try {
      conn.close();
      //JOptionPane.showMessageDialog(null,"Connection Closed.");
    } catch(Exception e) {
      JOptionPane.showMessageDialog(null,"Connection NOT Closed.");
    }//end try catch
	}

	
	/**
	 * Launch the application.
	 */
	//sets frame to visible. Needs to be called in main
	public void set_visible() {
		frame.setVisible(true);
	}

	//execute system queries
	void serverRequest(String command){
		String name = "";
		Vector<String> header = new Vector<String>(1);
		try{
			//create a statement object
			Statement stmt = conn.createStatement();
			//create an SQL statement
			String sqlStatement = command;
			//send statement to DBMS
			System.out.println("query executed, data requested");
			ResultSet result = stmt.executeQuery(sqlStatement);
			System.out.println("data received");

			//ResultSetMetaData md = result.getMetaData();
			int columns = tabBusiness.getSelectNum();
			System.out.println("check1");
//			for (int i = 1; i <= columns; i++) {
//		        header.add(md.getColumnName(i) + ", ");      
//		    }
			System.out.println("check2");
			while (result.next()) {
				String row = "";
				for(int i = 1; i <= columns; i++) {
					System.out.println("i = "+i);
					row += result.getString(i)+" | ";
					
				}
				System.out.println("while loop");
				name += row + "\n";
			}
			System.out.println("check3");
			//add file input
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		JOptionPane.showMessageDialog(null,name);
	}
	//displays name and address
	void serverRequest2(String command){
		String name = "";
		try{
			Statement stmt = conn.createStatement();
			String sqlStatement = command;
			System.out.println("query executed, data requested");
			ResultSet result = stmt.executeQuery(sqlStatement);
			System.out.println("data received");
			while (result.next()) {
				name += result.getString("name")+" | "+result.getString("address")+"\n";
			}
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		JOptionPane.showMessageDialog(null,name);
	}
	
	void serverRequestFileOut(String command){
		System.out.println("fileoutcalled");
		String name = "";
		try{
			FileWriter writeResults = new FileWriter("output.csv");
			//writeResults.write(name);
			Statement stmt = conn.createStatement();
			String sqlStatement = command;
			ResultSet result = stmt.executeQuery(sqlStatement);
			while (result.next()) {
				writeResults.write(result.getString("name")+"\n");
				//name += result.getString("name")+"\n";
			}
			writeResults.close();
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		
		
		
		//JOptionPane.showMessageDialog(null,name);
	}
	
	//for file output
	String buildOutput(ResultSet result){
		String name = "";
		try{
			while (result.next()) {
					name += result.getString("name")+" | "+result.getString("address")+"\n";
				}
		
			//add file input
		} catch (Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"Error accessing Database.");
		}
		return name;
	}


	
	void execute(String command) {
		serverRequest(command);
		
		
	}
	void serverRequestPhase4(String command){
		
	}



	/**
	 * Create the application.
	 */
	public FirstPageGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1066, 630);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		//Create tabbed JPanel inside of JFrame
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(30, 116, 945, 454);
		frame.getContentPane().add(tabbedPane);
		
		
		
		
		//business
		
		tabbedPane.add("Business", tabBusiness);
		//user
		UserPanel tabUser = new UserPanel();
		tabbedPane.add("User", tabUser);
		//review
		ReviewPanel tabReview = new ReviewPanel();
		tabbedPane.add("Review", tabReview);
		
		Phase4 phase4Panel = new Phase4();
		tabbedPane.add("Phase 4", phase4Panel);
		
		//End Panel Creation
///////////////////////////////////////////////////////////////////////////////////
//Top Row
///////////////////////////////////////////////////////////////////////////////////
		Button buttonClose = new Button("Close Connection and Exit");
		buttonClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("global variable select "+ select);
				closeConnection();
				System.exit(0);
				
			}
		});
		buttonClose.setBounds(745, 31, 168, 24);
		frame.getContentPane().add(buttonClose);
		
		//Query button
		Button buttonQuery = new Button("Query");
		buttonQuery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("global variable select "+ select);
				//execute();
				String command = "";
				//int currentPanel = tabbedPane.getSelectedIndex()
				if(tabbedPane.getSelectedIndex() == 0) {
					command = tabBusiness.buildCommand();
					tabBusiness.resetTextFields();
				}
				else if(tabbedPane.getSelectedIndex() == 1) {
					
				}
				else if(tabbedPane.getSelectedIndex() == 2) {
					
				}
				else if(tabbedPane.getSelectedIndex() == 3) {
					command = phase4Panel.buildCommand();
					phase4Panel.resetTextFields();
					if(fileFlag) {
						serverRequestFileOut(command);
						System.out.println("fileFlag");
					}else {
						System.out.println("else condition entered");
						serverRequestPhase4(command);
					}
				}
				//if file is to be outputted
				
				if(fileFlag) {
					serverRequestFileOut(command);
					System.out.println("fileFlag");
				}else {
					System.out.println("else condition entered");
					serverRequest(command);
				}
				//serverRequestFileOut(command)
				
				
				
			}
		});
		buttonQuery.setBounds(811, 79, 79, 24);
		frame.getContentPane().add(buttonQuery);
		
		
		
		Label labelOutput = new Label("Output:");
		labelOutput.setBounds(124, 59, 56, 24);
		frame.getContentPane().add(labelOutput);
		
		Choice choice_output = new Choice();
		choice_output.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String limit_choice = choice_output.getSelectedItem();
				switch(limit_choice) {
					case "5 lines":
						fileFlag = false;
						break;
					case "10 lines":
						fileFlag = false;
						break;
					case "results.txt":
						fileFlag = true;
						break;
					
					default:
						
				}
			}
		});
		choice_output.setBounds(212, 59, 71, 22);
		frame.getContentPane().add(choice_output);
		String out_lines5 = new String("5 lines");
		String out_lines10 = new String("10 lines");
		String out_file = new String("results.txt");
		choice_output.add(out_lines5);
		choice_output.add(out_lines10);
		choice_output.add(out_file);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//top row end
	}
}
