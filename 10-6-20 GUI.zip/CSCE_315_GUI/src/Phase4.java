import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import java.awt.Button;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.Label;
import java.awt.Checkbox;

public class Phase4 extends JPanel {

	private String restaurant1;
	private String restaurant2;
	private String user;
	private String state;
	private String city;
	
	boolean q1 = false;
	boolean q2 = false;
	boolean q3 = false;
	boolean q4 = false;
	
	TextField textField = new TextField();
	TextField textField_1 = new TextField();
	TextField textUser = new TextField();
	TextField textState = new TextField();
	TextField textCity = new TextField();
	/**
	 * Create the panel.
	 */
	
	public String buildCommand() {
		String command = "";
		if(q1) {
			//return "SELECT "+ "WHERE LIKE '%"+restaurant1+"%' "+ " '%"+restaurant2 + "%' ";
			command = "SELECT name from business_category WHERE category LIKE '%Shopping%' LIMIT 10;";
		}
		else if(q2) {
			command = "SELECT "+ "WHERE LIKE '%"+user+"%' ";
		}
		else if(q3) {
			command = "SELECT "+ "WHERE LIKE '%"+state+"%' ";
		}
		else if(q4) {
			command = "SELECT "+ "WHERE LIKE '%"+city+"%' ";
		}
		System.out.println(command);
		return command;
	}
	public void resetTextFields() {
		textField.setText("");

		textField_1.setText("");

		textUser.setText("");
		textState.setText("");
		textCity.setText("");
		
		//choiceState.set
		
		
	}
	public Phase4() {
		setLayout(null);
		
		
		textField.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				restaurant1 = textField.getText();
				System.out.println(textField.getText());
				
			}
		});
		textField.setBounds(274, 101, 132, 24);
		add(textField);
		
		
		textField_1.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				restaurant2 = textField_1.getText();
				System.out.println(textField_1.getText());
			}
		});
		textField_1.setBounds(527, 101, 132, 24);
		add(textField_1);
		
		Label label = new Label("Restaurant 1");
		label.setBounds(274, 71, 88, 24);
		add(label);
		
		Label label_1 = new Label("Restaurant 2");
		label_1.setBounds(527, 71, 88, 24);
		add(label_1);
		
		
		textUser.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				user = textUser.getText();
				System.out.println(user);
				
			}
		});
		textUser.setBounds(274, 168, 132, 24);
		add(textUser);
		
		Label label_2 = new Label("User");
		label_2.setBounds(274, 131, 70, 24);
		add(label_2);
		
		
		textState.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				state = textState.getText();
				System.out.println(state);
				
			}
		});
		textState.setBounds(274, 233, 132, 24);
		add(textState);
		
		Label label_3 = new Label("State");
		label_3.setBounds(274, 203, 70, 24);
		add(label_3);
		
		
		textCity.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				city = textCity.getText();
				System.out.println(city);
				
			}
		});
		textCity.setBounds(274, 295, 132, 24);
		add(textCity);
		
		Label label_4 = new Label("City");
		label_4.setBounds(274, 265, 70, 24);
		add(label_4);
		
		Checkbox checkbox = new Checkbox("Query 1");
		checkbox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				q1 = !q1;
				System.out.println("q1 = "+q1);
			}
		});
		checkbox.setBounds(44, 101, 108, 24);
		add(checkbox);
		
		Checkbox checkbox_1 = new Checkbox("Query 2");
		checkbox_1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				q2 = !q2;
				System.out.println("business toggle "+q2);
			}
		});
		checkbox_1.setBounds(44, 168, 108, 24);
		add(checkbox_1);
		
		Checkbox checkbox_2 = new Checkbox("Query 3");
		checkbox_2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				q3 = !q3;
				System.out.println("business toggle "+q3);
			}
		});
		checkbox_2.setBounds(44, 233, 108, 24);
		add(checkbox_2);
		
		Checkbox checkbox_3 = new Checkbox("Query 4");
		checkbox_3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				q4 = !q4;
				System.out.println("business toggle "+q4);
			}
		});
		checkbox_3.setBounds(44, 295, 108, 24);
		add(checkbox_3);

	}
}
