import java.awt.EventQueue;

import csce_GUI.Test_GUI;

public class Driver {
	//private JFrame frame;
	String select = "";

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstPageGUI window = new FirstPageGUI();
					window.set_visible();
					window.establishConnection();
					//window.testQuery();
					//window.callAll();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
