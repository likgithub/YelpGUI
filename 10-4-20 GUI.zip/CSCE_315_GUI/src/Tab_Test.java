import javax.swing.JPanel;
import javax.swing.JButton;

public class Tab_Test extends JPanel {

	/**
	 * Create the panel.
	 */
	public Tab_Test() {
		setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(162, 105, 97, 25);
		add(btnNewButton);

	}

}
