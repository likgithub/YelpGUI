import javax.swing.JPanel;

public class ReviewPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public ReviewPanel() {

	}

}
